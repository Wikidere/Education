#include <bits/stdc++.h>
using namespace std;
int t;
int move_brackets(string s)
{
    int d = 0, res = 0;
    for (auto x: s)
    if (x == '(') d++;
    else
    {
        d--;
        if (d < 0)
        {
            d = 0;
            res++;
        }
    }
    return res;
}
int main()
{
    freopen("mbrackets.inp","r",stdin);
    freopen("mbrackets.out","w",stdout);
    cin >> t;
    while (t--)
    {
        int n;
        string s;
        cin >> n >> s;
        cout << move_brackets(s) << '\n';
    }
    return 0;
}

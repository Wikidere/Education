#include <bits/stdc++.h>

using namespace std;
int n;
string s;
int main()
{
    ///freopen("filename.inp","r",stdin);
    ///freopen("filename.out","w",stdout);
    cin >> n >> s;
    s = s + 'a';
    int d = 0, res = 0;
    for (int i=0; i<s.size(); i++)
    if (s[i] == 'x') d++;
    else
    {
        if (d > 2) res += d - 2;
        d = 0;
    }
    cout << res;
    return 0;
}

#include <iostream>
#include <cstdio>
using namespace std;
string s;
void xuly()
{
    for (int i=0;i<=s.length()-1;i++)
    if (s[i] != '(' && s[i] != ')')
    {
        cout << "KHONG HOP LE";
        return;
    }
    int k;
    while ((k = s.find("()")) != string::npos) s.erase(k,2);
    if (s.empty()) cout << "DUNG";
    else cout << "KHONG DUNG";
}
int main()
{
    freopen("NGOAC.INP","r",stdin);
    freopen("NGOAC.OUT","w",stdout);
    getline(cin,s);
    xuly();
    return 0;
}

#include <bits/stdc++.h>

using namespace std;
string s1, s2;
int main()
{
    freopen("string.inp","r",stdin);
    freopen("string.out","w",stdout);
    while (cin >> s1 >> s2)
    {
        if (s1 == "END" && s2 == "END") break;
        sort(s1.begin(),s1.end());
        sort(s2.begin(),s2.end());
        if (s1 == s2) cout << "same";
        else    cout << "different";
        cout << endl;
    }
    return 0;
}

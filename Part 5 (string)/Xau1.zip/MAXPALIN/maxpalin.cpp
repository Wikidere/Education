#include <bits/stdc++.h>

using namespace std;
int n, maxlen = 1;
string s;
int maxPalin(int l, int r)
{
    while (s[l] == s[r] && l >= 0 && r < s.size())
    {
        l--; r++;
    }
    return r - l - 1;
}
int main()
{
    freopen("maxpalin.inp","r",stdin);
    freopen("maxpalin.out","w",stdout);
    cin >> n >> s;
    for (int i=1; i<s.size(); i++)
    {
        if (s[i-1] == s[i])
            maxlen = max(maxlen,maxPalin(i-1,i));
        if (i > 1 && s[i-2] == s[i])
            maxlen = max(maxlen,maxPalin(i-2,i));
    }
    cout << maxlen;
    return 0;
}

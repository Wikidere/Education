#include <bits/stdc++.h>
#include <sstream>  // for std::ostringstream
#include <string>   // for std::string
#include <unistd.h>
using namespace std;
const string baseFolderName = "test";

void create_test(char myfolder[],int id)
{
    freopen(myfolder,"w",stdout);
    int t,k;
    if (id <= 5)
    {
        t = rand() % 20 + 1;
        k = 30;
    }
    else
    {
        t = rand() % 5000 + 1;
        k = 100;
    }
    cout << t << '\n';
    for (int i=1; i<=t; i++)
    {
        int n = rand() % k + 1;
        string s = "";
        cout << n << '\n';
        for (int j=1; j<=n; j++)
        {
            int p = rand() % 2;
            int d = rand() % 2;
            if (p == 0)
            {
                if (d == 0) s.push_back('D');
                else s.push_back('U');
            }
            else
            {
                if (d == 0) s = s + "LR";
                else s = s + "RL";
            }
        }
        cout << s << '\n';
    }
}
int main()
{
    srand(time(NULL));
    for (int i = 1; i <= 20; ++i)
    {
        ostringstream folderName;
        if (i < 10)
            folderName << baseFolderName + "0" << i;
        else
            folderName << baseFolderName << i;
        mkdir(folderName.str().c_str());
        char filename[20];
        strcpy(filename, folderName.str().c_str());
        strcat(filename,"\\domino.inp");
        //freopen(filename,"w",stdout);
        //cout << rand() % 100;
        create_test(filename, i);
    }
    return 0;
}

#include <bits/stdc++.h>
#define N 100000
#define ll long long
using namespace std;
int n;
string s;
ll c[N+3],w[N+3];
ll ans = 0;
int main()
{
    freopen("cword.inp","r",stdin);
    freopen("cword.out","w",stdout);
    cin >> n >> s;
    c[0] = (s[0] == 'C');
    w[n-1] = (s[n-1] == 'W');
    for (int i=1; i<s.size(); i++)
    if (s[i] == 'C') c[i] = c[i-1] + 1;
    else c[i] = c[i-1];
    for (int i=s.size()-1; i>=0; i--)
    if (s[i] == 'W') w[i] = w[i+1] + 1;
    else w[i] = w[i+1];

    for (int i=1; i<s.size(); i++)
    if (s[i] == 'O')
        ans += c[i] * w[i];
    cout << ans;
    return 0;
}
